from google import genai
import os
from dotenv import load_dotenv

load_dotenv()

print("Key exists:", bool(os.getenv("GEMINI_API_KEY")))

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

print("Sending request...")

response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents="Say hello in one sentence."
)

print("Got response")
print(response.text)