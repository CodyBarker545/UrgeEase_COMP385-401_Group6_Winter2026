'use client'

import { redirect } from 'next/navigation'

export default function LegacySignUpPage() {
  redirect('/auth/sign-up')
}
